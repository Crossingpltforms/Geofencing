import React, { useState, useEffect } from 'react'
import { View, Text } from "react-native";
import * as commonStyle from '../../includes/main-style';
import Button from '../../components/Button/customButton.js'
import AsyncStorage from '@react-native-async-storage/async-storage';
import Amplify, { Auth, Hub } from 'aws-amplify';
import { getUser } from "../../includes/common-functions";
const Home = ({ routes, navigation }) => {
	console.log("routes", routes)
	console.log("navigation", navigation)
	const [user, setuser] = useState(null)
	const [submitDisbaled, changeSubmitDisbaled] = useState(false);

	React.useEffect(() => {
		setTimeout(async () => {
			getStorData();
		}, 1000)
	}, [])


	const getStorData = async () => {
		const userData = getUser().then((res) => {
			console.log("splash userData", res)
			if (res) {
				setuser(res.attributes)
			}
			else {
				navigation.navigate("Login");
			}
		}).catch((err) => console.log("djhjdhs", e))
		// console.log("getStorData caaled")
		// try {
		//   const jsonValue = await AsyncStorage.getItem('@USERINFO')
		//   const value = jsonValue != null ? jsonValue : null;
		//   console.log("===value",value)
		//   if(value !== null) {
		// 	setuser(JSON.parse(value))
		//   }
		// } catch(e) {
		//   // error reading value
		// }
	}
	const go = async () => {
		const doneout = await Auth.signOut();
		setTimeout(async () => {
			setuser(null)
			await AsyncStorage.removeItem('@USERINFO')
			navigation.navigate("Signup");
		}, 2000);
	}

	return (
		<View style={{ flex: 1, justifyContent: 'center' }}>
			{user ? (<Text style={{ alignSelf: 'center' }}>Hello, {user.given_name} {user.family_name}</Text>) : null}
			<View style={{ justifyContent: 'center', alignItems: 'center', marginTop: 10 }}>
				{
					user ? (<Button onClick={() => go()} text="Sign out" textColor="white" backgroundColor={submitDisbaled == true ? "rgb(159, 159, 159)" : commonStyle.themeColor()} disabled={submitDisbaled} />) : null}

			</View>
		</View>
	)
}
export default Home;

