import React, { useEffect, useState, createRef } from 'react';
import {GetAllLocations} from '../../services'
import {check, PERMISSIONS, RESULTS, request} from 'react-native-permissions';

import {
	StyleSheet,
	View,
	Text,
	Dimensions,
	TouchableOpacity,
	Image,
	Alert,
	ScrollView,
	FlatList,
	TextInput
} from 'react-native';
import * as style from './style'
import * as commonStyle from '../../includes/main-style';
import MapView, {
	Marker,
	Callout,
	CalloutSubview,
	ProviderPropType,
	AnimatedRegion,
	Animated,
	animateCamera
} from 'react-native-maps';
import flagImg from '../../assets/images/eventmarker.png';

import CustomCallout from './CustomCallout';
import Geolocation, { getCurrentPosition } from "react-native-geolocation-service";

const DATA = [
	{
		id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
		title: 'Turle Crossing',
		description: 'Clarence Foster Park DB mall',
		coord: { lat: 23.298109, lng: 77.380928 },
		identifier: 'mk1'
	},
	{
		id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
		title: 'Play ground',
		description: 'Clarence Foster Park malhar indore',
		coord: { lat: 22.726780, lng: 75.831830 },
		identifier: 'mk2'

	},
	{
		id: '58694a0f-3da1-471f-bd96-145571e29d72',
		title: 'Green Hub',
		description: 'Clarence Foster Park',
		coord: { lat: 22.761610, lng: 77.715170 },
		identifier: 'mk3'
	},
	{
		id: '58694a0f-3da1-47-bd96-145571e29d72',
		title: 'MD',
		description: 'MD',
		coord: { lat: 24.470901, lng: 39.612236 },
		identifier: 'mk3'
	},
];
const COORDINATESStatic = [{"latitude": 43.518902, "longitude": -124.87964}, {"latitude": 32.714214426953255, "longitude": -97.18181170055541}, {"latitude": 32.714279426890236, "longitude": -97.20007217651506}, {"latitude": 32.7024997, "longitude": -97.1619891}, {"latitude": 32.714139, "longitude": -97.159349}, {"latitude": 32.713, "longitude": -97.176}, {"latitude": 32.712783, "longitude": -97.1828}, {"latitude": 32.69946606511563, "longitude": -97.15477045501709}, {"latitude": 32.71620034309978, "longitude": -97.17230595180663}, {"latitude": 18.347845, "longitude": -64.777116}, {"latitude": 32.69998, "longitude": -97.155965}, {"latitude": 18.346505391253263, "longitude": -64.71247751749658}, {"latitude": 32.71257642590407, "longitude": -97.202163986969}, {"latitude": 18.359093, "longitude": -64.744066}, {"latitude": 32.678445, "longitude": -97.145711}, {"latitude": 32.702526, "longitude": -97.159087}, {"latitude": 32.727679051162234, "longitude": -97.18218731730308}, {"latitude": 32.7118464, "longitude": -97.1804158}, {"latitude": 18.331435, "longitude": -64.795856}]
const MARKERID = ['mk1', 'mk2', 'mk3'];

const { width, height } = Dimensions.get('window');
const ASPECT_RATIO = width / height;
const LATITUDE = 37.78825;
const LONGITUDE = -122.4324;
const LATITUDE_DELTA = 0.0922;
// const LATITUDE_DELTA = 60 //Very high zoom level
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;
const SPACE = 0.01;


import ActionSheet from "react-native-actions-sheet";
const actionSheetRef = createRef();




const Home = ({ route, navigation }) => {

	const [selectedId, setSelectedId] = useState(null);
	const [selectedTag, setSelectedTag] = useState("");
	const [selectedPlace, setSelectedPlace] = useState("");
	const [locationData, seLocationData] = useState([]);
	const [coordinates, setCoordinates] = useState([]);
	const [selectedItem, setSelectedItem] = useState({});
	const [lat, setLat] = useState(0);
	const [lng, setlng] = useState(0);
	const [marker, setmarker] = useState([]);
	const [region, setRegion] = useState({
		latitude: 0,
		longitude: 0,
		latitudeDelta: 0.005,
		longitudeDelta: 0.005
	});
	useEffect(() => {

		// _getCurrentPosition();
		_getAllLocation()

	}, [])
	 _getAllLocation = async() =>{
		const allLocations = await GetAllLocations();	
		// console.log("==>allLocations",allLocations)
		
		seLocationData(allLocations.data)
		// setmarker(marker => [...marker, { lat: lat, lng: lng }])
		// const aa = ;
		setCoordinates(allLocations.coords)
		
	}
	_getCurrentPosition = () => {
		check(PERMISSIONS.IOS.LOCATION_ALWAYS)
			.then((result) => {
				console.log("permission result",result)
				switch (result) {
				  case RESULTS.UNAVAILABLE:
					console.log('This feature is not available (on this device / in this context)');
					break;
				  case RESULTS.DENIED:
					console.log('The permission has not been requested / is denied but requestable');
					request(PERMISSIONS.IOS.LOCATION_ALWAYS).then((result) => {
						console.log("permission  request result",result)
					  });
					break;
				  case RESULTS.LIMITED:
					console.log('The permission is limited: some actions are possible');
					break;
				  case RESULTS.GRANTED:
					console.log('The permission is granted');
					break;
				  case RESULTS.BLOCKED:
					console.log('The permission is denied and not requestable anymore');
					break;
				}
			  })
			  .catch((error) => {
				console.log("error check permission", error)
			  });
		
		Geolocation.getCurrentPosition(
			(position) => {

				setLat(position.coords.latitude);
				setlng(position.coords.longitude);
				// setLat(22.745880);
				// setlng(75.869780);
				setRegion({
					latitude: parseFloat(position.coords.latitude),
					longitude: parseFloat(position.coords.latitude),
					latitudeDelta: 0.005,
					longitudeDelta: 0.005
				});
				console.log("position=>", position)


				// console.log("hello", JSON.stringify(position, null, null));
				// const timeout = setTimeout(() => {
				// 	 _moveMap(position.coords.latitude,position.coords.latitude)
				// }, 3000);
			},
			(error) => {
				// See error code charts below.
				// alert(error.message)
				console.log("geolocation error",error.code, error.message);
				return;
			},
			{ enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 }
		);
	}
	_moveMap = (currentlat, currentlng) => {
		_mapView.animateToRegion({
			latitude: currentlat,
			longitude: currentlng,
			latitudeDelta: 0.005,
			longitudeDelta: 0.005,
		}, 2000)
		// alert("_moveMap");
	}
	_activityPress = (item) => {
		setSelectedItem(item)
		_mapView.animateToRegion({
			latitude: item.lat,
			longitude: item.lng,
			latitudeDelta: 0.005,
			longitudeDelta: 0.005,
		}, 2000)
	}
	const Item = ({ item, onPress, style }) => (
		<TouchableOpacity onPress={() => _activityPress(item)} style={[{
			height: 'auto',
			width: commonStyle.getResponsiveScreenWidthDivide(1.5),
			marginVertical: commonStyle.getModerateScale(8),
			marginHorizontal: commonStyle.getModerateScale(8),
			padding: commonStyle.getModerateScale(10),
			borderRadius: commonStyle.getModerateScale(10)
		}, style]}>
			<Text style={{ fontSize: commonStyle.getModerateScale(20), fontWeight: 'bold', color: 'white' }} numberOfLines={2}>Name: {item.tag}</Text>
			<Text style={{ marginTop: commonStyle.getModerateScale(10), fontSize: commonStyle.getModerateScale(14), color: 'white' }} numberOfLines={3}>Location Name: {item.place}</Text>

		</TouchableOpacity>
	);
	const renderItem = ({ item }) => {
		// console.log("item",item)
		const backgroundColor = item.id === selectedId ? "green" : commonStyle.themeColor();
		return (
			<Item
				item={item}
				onPress={() => setSelectedId(item.id)}
				style={[{ backgroundColor }]}
			/>
		);
	};

	_renderMarker = () => {
		setmarker(marker => [...marker, { lat: lat, lng: lng }])
		// _mapView.fitToElements(true)
		// console.log("coordinates",coordinates)
		
		// _mapView.fitToCoordinates(coordinates[coordinates.length-1], { edgePadding: { top: 10, right: 10, bottom: 10, left: 10 }, animated: true })
	}
	_onMarkerPress = (item) => {

		console.log("iii",item)
		
		setSelectedItem(item)
		setSelectedTag(item.tag)
		setSelectedPlace(item.place)
		actionSheetRef.current?.show()
	}
	_navigateToEvent = () => {
		
		actionSheetRef.current?.hide()
		// navigation.navigate("Notes",{selectedActivity:selectedItem});
		navigation.navigate("Notes",{selectedActivity:selectedItem});
	}
	_onMapReady = () => {
		// _mapView.animateToRegion({
		// 	latitude: lat,
		// 	longitude: lng,
		// 	latitudeDelta: 0.005*150,
		// 	longitudeDelta: 0.005*150,
		// })
		
		// _mapView.fitToSuppliedMarkers(['mk1','mk2'],{ edgePadding: 
		// 	{top: 50,
		// 	  right: 50,
		// 	  bottom: 50,
		// 	  left: 50}, animated:true

		//   })
		
		const timeout = setTimeout(() => {
		// 	console.log("on map ready ready", coordinates, COORDINATESStatic)
		// 	const a =setCoordinates(coordinates.reverse())
		// _mapView.fitToCoordinates(coordinates[0], { edgePadding: { top: 10, right: 10, bottom: 10, left: 10 }, animated: true })
		_mapView.fitToCoordinates(coordinates, { edgePadding: { top: 0, right: 0, bottom: 0, left: 0 }, animated: false })
				}, 1000);
	}
	return (
		<View style={styles.container}>
			<ActionSheet
				ref={actionSheetRef}
				containerStyle={{ margin: 10, borderRadius: 5 }}
				separateHeight={3}
				separateColor="black"
				backgroundColor="rgba(0, 0, 0, 0.3)"
				containerStyle={{ margin: 10, borderRadius: 5 }}
				gestureEnabled={true}
				closeOnPressBack={true}
			>
				<style.ActionSheetConatiner>
					<style.TimeStampContainer>
					</style.TimeStampContainer>
					<style.FormContainer>
						<style.InputArea>
							<style.InputLebal >Name:</style.InputLebal>
							<style.TextInput placeholder="" value = {selectedTag}/>
						</style.InputArea>
						<style.InputAreaPlace>
							<style.InputLebal >Place:</style.InputLebal>
							<style.TextInput placeholder="" value = {selectedPlace}/>
						</style.InputAreaPlace>
					</style.FormContainer>
					<style.ImageContainer>
						<style.ImageContainerSmall>
							<style.ImageAndTitle onPress={() => _navigateToEvent()}>
								<style.Image resizeMode='contain' source={require('../../assets/images/addnotes.png')}></style.Image>
								<style.ImageTitle>
									Add Notes
							</style.ImageTitle>
							</style.ImageAndTitle>
							<style.AndText>And</style.AndText>
							<style.ImageAndTitle onPress={() => _navigateToEvent()}>
								<style.ImagePhotos resizeMode='contain' source={require('../../assets/images/addphoto.png')}></style.ImagePhotos>
								<style.ImagePhotoTitle>
									Add Photos
							</style.ImagePhotoTitle>
							</style.ImageAndTitle>
						</style.ImageContainerSmall>
					</style.ImageContainer>
				</style.ActionSheetConatiner>
			</ActionSheet>
			<View style={{ flex: 1 }}>
				<MapView
					ref={(mapView) => { _mapView = mapView; }}
					// mapType={Platform.OS == "android" ? "none" : "standard"}
					style={styles.map}
					zoomEnabled={true}
					zoomControlEnabled={true}
					// initialRegion={{
					// 	latitude: lat,
					// 	longitude: lng,
					// 	latitudeDelta: LATITUDE_DELTA,
					// 	longitudeDelta: LONGITUDE_DELTA
					// }}
					onMapReady={() => _onMapReady()}
					
					
					

					showsMyLocationButton={true}
					showsCompass={true}
					// showsUserLocation={true}
					followUserLocation={true}
					rotateEnabled={false}
					loadingEnabled={true}
					
					// onLayout={() => _mapView.fitToCoordinates(COORDINATES, { edgePadding: { top: 50, right: 10, bottom: 10, left: 10 }, animated: false })} >
					// clustering={true} with refer https://blog.bam.tech/developer-news/four-tips-optimize-react-native-map-performance-user-experience
					// region={region}

				// onRegionChangeComplete={region => setRegion(region)}
				>
					
					{
					locationData.map((item, index) => {
						// console.log("DATA marker", item)
						
						return (
							<MapView.Marker.Animated
								key={index}
								coordinate={{ latitude: item.lat, longitude: item.lng }}
								// title={"he"}
								// description={"bus.order"}
								image={flagImg}
								// anchor={{ x: 0.125, y: 0.1 }}
								// centerOffset={{ x: 0, y: 0 }}
								// calloutAnchor={{ x: 0, y: 0 }}
								onPress={() => { _onMarkerPress(item) }}
								identifier={index.toString()}
								
							>
							</MapView.Marker.Animated>
						)
					})}
				</MapView>


				<View style={{ flexDirection: 'row', marginTop: 20, justifyContent: 'space-between' }}>
					<View style={{
						justifyContent: 'center', alignItems: 'center', backgroundColor: 'white', flexDirection: 'row', marginVertical: 10, marginHorizontal: 10, borderRadius: commonStyle.getModerateScale(20), padding: commonStyle.getModerateScale(9), borderColor: '#9AA1B0', borderWidth: 0.6, shadowColor: "#000",
						shadowOffset: {
							width: 0,
							height: 2,
						},
						shadowOpacity: 0.25,
						shadowRadius: 3.84,
						elevation: 5,
					}}>
						<TouchableOpacity activeOpacity={.5}>
							<Image source={require('../../assets/images/iconmap.png')} style={{ height: commonStyle.getModerateScale(25), width: commonStyle.getModerateScale(25) }} />
						</TouchableOpacity>
						<TouchableOpacity style={{ marginLeft: 12, marginRight: 12 }} activeOpacity={.5} onPress={() => navigation.navigate("Events")}>
							<Image source={require('../../assets/images/iconclipboard.png')} style={{ height: commonStyle.getModerateScale(25), width: commonStyle.getModerateScale(25) }} />
						</TouchableOpacity>
						<TouchableOpacity activeOpacity={.5} onPress={() => navigation.navigate('Profile')}>
							<Image source={require('../../assets/images/iconfilter.png')} style={{ height: commonStyle.getModerateScale(25), width: commonStyle.getModerateScale(25) }} />
						</TouchableOpacity>

					</View>
					<View style={{}}>
						<TouchableOpacity
							style={{ justifyContent: 'center' }}
							onPress={() => _renderMarker()}
						>
							<Image source={require('../../assets/images/markerplus.png')} style={{
								width: commonStyle.getModerateScale(100),
								height: commonStyle.getModerateScale(60),
								resizeMode: 'contain', alignSelf: 'center', alignItems: 'center'
							}} />
						</TouchableOpacity>
					</View>
				</View>
			</View>

			<View >
				<ScrollView horizontal={true} >
					<FlatList
						data={locationData}
						renderItem={renderItem}
						keyExtractor={({ lat }) => lat}
						extraData={selectedId}
						horizontal={true}
						
					/>
				</ScrollView>
				{/* <Text>{JSON.stringify(coordinates)}</Text> */}
			</View>
		</View>
	);

}

Home.propTypes = {
	provider: ProviderPropType,
};

const styles = StyleSheet.create({
	customView: {
		width: 140,
		height: 140,
	},
	plainView: {
		width: 60,
	},
	container: {
		// ...StyleSheet.absoluteFillObject,
		// justifyContent: 'flex-start',
		// alignItems: 'center',
		flex: 1,
		flexDirection: 'column'

	},
	map: {
		...StyleSheet.absoluteFillObject,
	},
	bubble: {
		flex: 1,
		backgroundColor: 'rgba(255,255,255,0.7)',
		paddingHorizontal: 18,
		paddingVertical: 12,
		borderRadius: 20,
	},
	latlng: {
		width: 200,
		alignItems: 'stretch',
	},
	button: {
		width: 80,
		paddingHorizontal: 12,
		alignItems: 'center',
		marginHorizontal: 10,
	},
	buttonContainer: {
		flexDirection: 'row',
		marginVertical: 20,
		backgroundColor: 'transparent',
	},
	calloutButton: {
		width: 'auto',
		backgroundColor: 'rgba(255,255,255,0.7)',
		paddingHorizontal: 6,
		paddingVertical: 6,
		borderRadius: 12,
		alignItems: 'center',
		marginHorizontal: 10,
		marginVertical: 10,
	},
});

export default Home;
